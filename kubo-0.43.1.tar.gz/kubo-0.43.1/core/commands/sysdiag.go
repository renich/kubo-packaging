package commands

import (
	"os"
	"runtime"

	"github.com/ipfs/go-ipfs-cmds"
	version "github.com/ipfs/kubo"
	"github.com/ipfs/kubo/config"
	"github.com/ipfs/kubo/core"
	cmdenv "github.com/ipfs/kubo/core/commands/cmdenv"
	manet "github.com/multiformats/go-multiaddr/net"
	sysi "github.com/whyrusleeping/go-sysinfo"
)

var sysDiagCmd = &cmds.Command{
	Helptext: cmds.HelpText{
		Tagline: "Print system diagnostic information.",
		ShortDescription: `
Prints out information about your computer to aid in easier debugging.
`,
	},
	Run: func(req *cmds.Request, res cmds.ResponseEmitter, env cmds.Environment) error {
		nd, err := cmdenv.GetNode(env)
		if err != nil {
			return err
		}

		info, err := getInfo(nd)
		if err != nil {
			return err
		}
		return cmds.EmitOnce(res, info)
	},
}

func getInfo(nd *core.IpfsNode) (map[string]any, error) {
	info := make(map[string]any)
	err := runtimeInfo(info)
	if err != nil {
		return nil, err
	}

	err = envVarInfo(info)
	if err != nil {
		return nil, err
	}

	err = diskSpaceInfo(info)
	if err != nil {
		return nil, err
	}

	err = memInfo(info)
	if err != nil {
		return nil, err
	}

	err = netInfo(nd.IsOnline, info)
	if err != nil {
		return nil, err
	}

	info["ipfs_version"] = version.CurrentVersionNumber
	info["ipfs_commit"] = version.CurrentCommit
	return info, nil
}

func runtimeInfo(out map[string]any) error {
	rt := make(map[string]any)
	rt["os"] = runtime.GOOS
	rt["arch"] = runtime.GOARCH
	rt["compiler"] = runtime.Compiler
	rt["version"] = runtime.Version()
	rt["numcpu"] = runtime.NumCPU()
	rt["gomaxprocs"] = runtime.GOMAXPROCS(0)
	rt["numgoroutines"] = runtime.NumGoroutine()

	out["runtime"] = rt
	return nil
}

func envVarInfo(out map[string]any) error {
	ev := make(map[string]any)
	ev["GOPATH"] = os.Getenv("GOPATH")
	ev[config.EnvDir] = os.Getenv(config.EnvDir)

	out["environment"] = ev
	return nil
}

func diskSpaceInfo(out map[string]any) error {
	pathRoot, err := config.PathRoot()
	if err != nil {
		return err
	}
	dinfo, err := sysi.DiskUsage(pathRoot)
	if err != nil {
		return err
	}

	out["diskinfo"] = map[string]any{
		"fstype":      dinfo.FsType,
		"total_space": dinfo.Total,
		"free_space":  dinfo.Free,
	}

	return nil
}

func memInfo(out map[string]any) error {
	m := make(map[string]any)

	meminf, err := sysi.MemoryInfo()
	if err != nil {
		return err
	}

	m["swap"] = meminf.Swap
	m["virt"] = meminf.Used
	out["memory"] = m
	return nil
}

func netInfo(online bool, out map[string]any) error {
	n := make(map[string]any)
	addrs, err := manet.InterfaceMultiaddrs()
	if err != nil {
		return err
	}

	straddrs := make([]string, len(addrs))
	for i, a := range addrs {
		straddrs[i] = a.String()
	}

	n["interface_addresses"] = straddrs
	n["online"] = online
	out["net"] = n
	return nil
}
